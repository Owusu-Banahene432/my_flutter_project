import 'package:flutter/material.dart';
class Saved extends StatefulWidget {
  Saved({Key? key}) : super(key: key);

  @override
  _SavedState createState() => _SavedState();
}

class _SavedState extends State<Saved> {
  @override
  Widget build(BuildContext context) {
    return Container(
       child: Center(
         child: Text('Saved pages'),
       ),
    );
  }
}